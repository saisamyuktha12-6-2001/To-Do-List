# GUI-based To-Do List application using Tkinter

import tkinter as tk
from tkinter import messagebox

class ToDoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("To-Do List")
        
        self.tasks = []
        
        self.task_entry = tk.Entry(self.root, width=50)
        self.task_entry.pack(pady=10)
        
        self.add_task_button = tk.Button(self.root, text="Add Task", command=self.add_task)
        self.add_task_button.pack(pady=5)
        
        self.tasks_frame = tk.Frame(self.root)
        self.tasks_frame.pack(pady=10)
        
        self.tasks_listbox = tk.Listbox(self.tasks_frame, width=50, height=10)
        self.tasks_listbox.pack(side="left")
        
        self.tasks_scrollbar = tk.Scrollbar(self.tasks_frame)
        self.tasks_scrollbar.pack(side="right", fill="y")
        
        self.tasks_listbox.config(yscrollcommand=self.tasks_scrollbar.set)
        self.tasks_scrollbar.config(command=self.tasks_listbox.yview)
        
        self.update_task_button = tk.Button(self.root, text="Update Task", command=self.update_task)
        self.update_task_button.pack(pady=5)
        
        self.complete_task_button = tk.Button(self.root, text="Complete Task", command=self.complete_task)
        self.complete_task_button.pack(pady=5)
        
        self.show_tasks_button = tk.Button(self.root, text="Show Tasks", command=self.show_tasks)
        self.show_tasks_button.pack(pady=5)

    def add_task(self):
        task = self.task_entry.get()
        if task:
            self.tasks.append({"task": task, "completed": False})
            self.task_entry.delete(0, tk.END)
            self.show_tasks()
        else:
            messagebox.showwarning("Warning", "You must enter a task")

    def update_task(self):
        selected_task_index = self.tasks_listbox.curselection()
        if selected_task_index:
            new_task = self.task_entry.get()
            if new_task:
                index = selected_task_index[0]
                self.tasks[index]["task"] = new_task
                self.task_entry.delete(0, tk.END)
                self.show_tasks()
            else:
                messagebox.showwarning("Warning", "You must enter a task")
        else:
            messagebox.showwarning("Warning", "You must select a task to update")

    def complete_task(self):
        selected_task_index = self.tasks_listbox.curselection()
        if selected_task_index:
            index = selected_task_index[0]
            self.tasks[index]["completed"] = True
            self.show_tasks()
        else:
            messagebox.showwarning("Warning", "You must select a task to complete")

    def show_tasks(self):
        self.tasks_listbox.delete(0, tk.END)
        for i, task in enumerate(self.tasks):
            status = "Done" if task["completed"] else "Not Done"
            self.tasks_listbox.insert(tk.END, f"{i + 1}. {task['task']} - {status}")

if __name__ == "__main__":
    root = tk.Tk()
    app = ToDoApp(root)
    root.mainloop()
